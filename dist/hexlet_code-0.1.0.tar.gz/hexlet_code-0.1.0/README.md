### Hexlet tests and linter status:
[![Actions Status](https://github.com/mym1chelle/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/mym1chelle/python-project-49/actions)

### Maintainability Badge:
<a href="https://codeclimate.com/github/mym1chelle/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/5408926373a5b0548904/maintainability" /></a>

### ASCIINEMA Files:
<a href="https://asciinema.org/a/DkbB9dntRahJV34IxtpbmOcwU">brain-even</a>
<a href="https://asciinema.org/a/X7CD3VxNeVgMRWXXRc1X1wsUm">brain-calc</a>
<a href="https://asciinema.org/a/nvStJ2QUE2ZkxcFsD95k8v44d">brain-gcd</a>
<a href="https://asciinema.org/a/mTB473F73WqeM7J1e1FHQF1pc">brain-progression</a>
